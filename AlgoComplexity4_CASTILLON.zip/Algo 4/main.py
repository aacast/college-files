import pygame
import sys
from pygame import gfxdraw
import graph
from pygame.locals import *
import polytri
import easygui

def process():
    gen = polytri.triangulate_poly(pts)
    adj_matrix = [[0 for __ in range(count)] for _ in range(count)]
    for x in gen:

        triangles.append(x[0])
        ears.append(x[1])
        x = x[0]
        adj_matrix[x[0][2]][x[1][2]] = 1
        adj_matrix[x[1][2]][x[0][2]] = 1
        adj_matrix[x[2][2]][x[1][2]] = 1
        adj_matrix[x[1][2]][x[2][2]] = 1
        adj_matrix[x[2][2]][x[0][2]] = 1
        adj_matrix[x[0][2]][x[2][2]] = 1

    g = graph.Graph(count)
    g.graph = adj_matrix
    m = 3
    coloring = g.graphColouring(m)

    i = 0

    for c in coloring:
        coloring3.append(c)
        rgbCount[c - 1] += 1
        variations[c - 1].append([i, pts[i][:2]])
        i += 1
    rgbMin = min(rgbCount)

    for i in range(len(rgbCount)):
        if rgbCount[i] == rgbMin:
            validColors.append(i)
    currVariationDisplayed = 0
    guardSelected = 0


def _intersection(P1, P2, P3):
    return (P3[1] - P1[1]) * (P2[0] - P1[0]) > (P2[1] - P1[1]) * (P3[0] - P1[0])

def findIntersection(S1x, S1y, D1x, D1y, S2x, S2y, D2x, D2y):
    return _intersection([S1x, S1y], [S2x, S2y], [D2x, D2y]) != _intersection([D1x, D1y], [S2x, S2y], [D2x, D2y]) and _intersection([S1x, S1y], [D1x, D1y], [S2x, S2y]) != _intersection([S1x, S1y], [D1x, D1y], [D2x, D2y])

def displayStatus(statusMsg):
    gfxdraw.filled_polygon(
        screen, [[0, 0], [0, 24], [WINDOW_WIDTH, 24], [WINDOW_WIDTH, 0]], WHITE)
    status = myfont.render(
        statusMsg, 1,
        BLACK)
    screen.blit(status, (10, 10))


def displayLabel1(labelMsg):
    gfxdraw.filled_polygon(screen, [[0, WINDOW_HEIGHT - 30], [0, WINDOW_HEIGHT - 16], [
                           WINDOW_WIDTH, WINDOW_HEIGHT - 16], [WINDOW_WIDTH, WINDOW_HEIGHT - 30]], WHITE)
    label1 = myfont.render(labelMsg, 1, BLACK)
    screen.blit(label1, (10, WINDOW_HEIGHT - 30))


def displayLabel2(labelMsg):
    gfxdraw.filled_polygon(screen, [[0, WINDOW_HEIGHT - 15], [0, WINDOW_HEIGHT], [
                           WINDOW_WIDTH, WINDOW_HEIGHT], [WINDOW_WIDTH, WINDOW_HEIGHT - 15]], WHITE)
    label2 = myfont.render(labelMsg, 1, BLACK)
    screen.blit(label2, (10, WINDOW_HEIGHT - 15))

def displayVariation(variation):
    screen.fill(WHITE)

    displayLabel2("Press backspace to reset")
    displayStatus("Cameras Needed: " + str(len(variation)))

    pygame.draw.aaline(screen, BLACK, (0, 25), (WINDOW_WIDTH, 25))
    pygame.draw.aaline(screen, BLACK, (0, WINDOW_HEIGHT - 33),
                       (WINDOW_WIDTH, WINDOW_HEIGHT - 33))

rgbCount = [0, 0, 0]

def displayTriangulated():
    screen.fill(WHITE)
    displayStatus("Displaying Triangulated Polygon")
    displayLabel2("Press backspace to reset")
    pygame.draw.aaline(screen, BLACK, (0, 25), (WINDOW_WIDTH, 25))
    pygame.draw.aaline(screen, BLACK, (0, WINDOW_HEIGHT - 33),
                       (WINDOW_WIDTH, WINDOW_HEIGHT - 33))

    for tri in triangles:
        # print(tri)
        if [tri[0][0], tri[0][1]] not in triPts:
            triPts.append([tri[0][0], tri[0][1]])
        if [tri[1][0], tri[1][1]] not in triPts:
            triPts.append([tri[1][0], tri[1][1]])
        if [tri[2][0], tri[2][1]] not in triPts:
            triPts.append([tri[2][0], tri[2][1]])
        pygame.draw.polygon(
            screen, BLUE, [tri[0][:2], tri[1][:2], tri[2][:2]], 1)


def display3Colors(i):
    index = -1
    for pt in points:
        index += 1
        if triPts[i] == pt[:2]:
            break
    pygame.draw.circle(screen, rgb[coloring3[index] - 1], triPts[i], 5)

pygame.init()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

rgb = [RED, GREEN, BLUE]

WINDOW_WIDTH = 1080
WINDOW_HEIGHT = 720

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Monotone Polygon Triangulation [Castillon]')
screen.fill(WHITE)
myfont = pygame.font.SysFont("Arial", 12)

label2 = myfont.render("", 1, BLACK)
screen.blit(label2, (10, WINDOW_HEIGHT - 15))

status = myfont.render(
    "Press space to run", 1,
    BLACK)
screen.blit(status, (10, 10))
pygame.draw.aaline(screen, BLACK, (0, 25), (WINDOW_WIDTH, 25))
pygame.draw.aaline(screen, BLACK, (0, WINDOW_HEIGHT-33),
                   (WINDOW_WIDTH, WINDOW_HEIGHT-33))
clock = pygame.time.Clock()


lock = 0
pts = []
points = []
mouse_lock = True
count = 0

variations = [[], [], []]
validColors = []
currVariationDisplayed = 0
guardSelected = 0
processed = 0
finished = 0
stepsFinish = 0
triangles = []
ears = []
triI = -1
coloring3 = []
colI = -1
triPts = []

while True:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == QUIT or pygame.key.get_pressed()[K_ESCAPE]:
            pygame.quit()
            sys.exit()

        if event.type == KEYDOWN and pygame.key.get_pressed()[K_SPACE] and lock != 1:
            path = "sample.csv"
            intersection = False
            with open(path) as dataFile:
                for line in dataFile:
                    lineSplit = line.split(",")
                    currentPoint = [int(lineSplit[0]), int(lineSplit[1])]
                    for i in range(len(pts) - 2):
                        if findIntersection(currentPoint[0], currentPoint[1], pts[len(pts) - 1][0], pts[len(pts) - 1][1], pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1]):
                            intersection = True
                            break
                    if not intersection:
                        pt = [currentPoint[0], currentPoint[1], count]
                        count += 1
                        pts.append(pt)
                        points.append(pt[:2])
                        pygame.draw.circle(screen, BLACK, currentPoint, 3)
                        pygame.font.init()
                        myfont2 = pygame.font.SysFont('Arial', 12)
                        textsurface = myfont2.render(
                            str(count - 1), False, (0, 0, 0))
                        screen.blit(textsurface, (currentPoint[0], currentPoint[1]))
                        if len(pts) > 1:
                            pygame.draw.aaline(
                                screen, BLACK, pts[len(pts) - 2][:2], currentPoint)
                    else:
                        break

                displayLabel2("Press backspace to reset")
                displayStatus("Press space to run")
                if not intersection:
                    for i in range(1, len(pts) - 2):
                        if findIntersection(pts[len(pts) - 1][0], pts[len(pts) - 1][1], pts[0][0], pts[0][1], pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1]):
                            intersection = True
                            break

                if not intersection:
                    pygame.draw.aaline(
                        screen, BLACK, pts[len(pts) - 1][:2], pts[0][:2])
                    lock = 1
                else:
                    screen.fill(WHITE)

                    lock = 0
                    pts = []
                    points = []
                    count = 0

                    variations = [[], [], []]
                    validColors = []
                    currVariationDisplayed = 0
                    guardSelected = 0
                    processed = 0
                    finished = 0
                    stepsFinish = 0
                    triangles = []
                    ears = []
                    triI = -1
                    coloring3 = []
                    colI = -1
                    triPts = []

                    pygame.draw.aaline(screen, BLACK, (0, 25), (WINDOW_WIDTH, 25))
                    pygame.draw.aaline(
                        screen, BLACK, (0, WINDOW_HEIGHT - 33), (WINDOW_WIDTH, WINDOW_HEIGHT - 33))
                    displayLabel2("Press backspace to reset")
                    displayStatus("Cannot create simple polygon. Vertex " + str(currentPoint) + " doesn't produce a simple polygon.")

        if event.type == KEYDOWN and pygame.key.get_pressed()[K_SPACE] and lock == 1:
            process()
            processed = 1

            displayStatus("Displaying Triangulated Polygon")
            displayTriangulated()
            pygame.display.update()
            pygame.time.delay(1000)

            camLabel = myfont.render(
                "Cameras Needed: " + str(len(variations[validColors[currVariationDisplayed]])), 1, BLACK)
            screen.blit(camLabel, (920, 480))
            redCam = myfont.render(
                "Reds: " + str(rgbCount[0]), 1, RED)
            screen.blit(redCam, (920, 500))
            greenCam = myfont.render(
                "Greens: " + str(rgbCount[1]), 1, GREEN)
            screen.blit(greenCam, (920, 520))
            blueCam = myfont.render(
                "Blues: " + str(rgbCount[2]), 1, BLUE)
            screen.blit(blueCam, (920, 540))

            while colI < len(points)-1:
                colI += 1
                display3Colors(colI)
                pygame.display.update()
                pygame.time.delay(1000)

        if event.type == KEYDOWN and pygame.key.get_pressed()[K_BACKSPACE]:
            screen.fill(WHITE)

            lock = 0
            pts = []
            points = []
            count = 0

            variations = [[], [], []]
            validColors = []
            currVariationDisplayed = 0
            guardSelected = 0
            processed = 0
            finished = 0
            stepsFinish = 0
            triangles = []
            ears = []
            triI = -1
            coloring3 = []
            colI = -1
            triPts = []

            pygame.draw.aaline(screen, BLACK, (0, 25), (WINDOW_WIDTH, 25))
            pygame.draw.aaline(
                screen, BLACK, (0, WINDOW_HEIGHT - 33), (WINDOW_WIDTH, WINDOW_HEIGHT - 33))
            rgbCount = [0, 0, 0]
            displayStatus("Press space to run")

    pygame.display.update()
